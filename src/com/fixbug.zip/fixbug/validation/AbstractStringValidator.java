package com.fixbug.validation;

public abstract class AbstractStringValidator {

    public abstract void validate(String value);

}
