package lesson9.homework.quadrilateral;

public class Square extends Rectangle {

    private int side;


    public Square(int side) {
        this.side = side;
    }

    @Override
    public int getArea() {
        return side*side;
    }

    @Override
    public int getPerimeter() {
        return side * 4;
    }
}
