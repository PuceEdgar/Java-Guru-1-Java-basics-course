package lesson9.homework.quadrilateral;

public class Rectangle extends Parallelogram {

    public Rectangle(){};

    public Rectangle(int length, int width) {
        super(length, width);
    }
}
