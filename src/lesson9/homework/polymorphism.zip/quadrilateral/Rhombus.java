package lesson9.homework.quadrilateral;

public class Rhombus extends Parallelogram {


    public Rhombus(int length, int width) {
        super(length, width);
    }

}
