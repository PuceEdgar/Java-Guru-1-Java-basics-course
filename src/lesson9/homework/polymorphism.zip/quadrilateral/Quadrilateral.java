package lesson9.homework.quadrilateral;

public abstract class Quadrilateral {


    public abstract int getArea();

    public abstract int getPerimeter();

}
