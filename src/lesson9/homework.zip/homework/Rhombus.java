package lesson9.homework;

public class Rhombus extends Parallelogram {

    public Rhombus(int length, int width) {
        super(length, width);
    }
}
