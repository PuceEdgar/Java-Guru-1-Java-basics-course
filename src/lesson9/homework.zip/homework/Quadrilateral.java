package lesson9.homework;

public abstract class Quadrilateral {

    private int length;
    private int width;

    public Quadrilateral(int length, int width) {
        this.length = length;
        this.width = width;
    }

    public int getArea(){
        return length * width;
    }

    public int getPerimeter(){
        return (length + width) * 2;
    }
}
