package lesson9.homework;

public class Rectangle extends Parallelogram {

    public Rectangle(int length, int width) {
        super(length, width);
    }
}
