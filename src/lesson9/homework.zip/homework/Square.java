package lesson9.homework;

public class Square extends Rectangle {

    public Square(int length, int width) {
        super(length, width);
    }
}
