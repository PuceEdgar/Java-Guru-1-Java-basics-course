package lesson9.homework;

public class Parallelogram extends Quadrilateral {


    public Parallelogram(int length, int width) {
        super(length, width);
    }
}
