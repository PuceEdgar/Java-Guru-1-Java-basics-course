package lesson5.product;

public class ProductMain {

    public static void main(String[] args) {

        Product beer = new Product("beer", 2.55);

        for (int i = 0, j = 5; i < 10; i++, j+=5) {
            beer.setDiscount(j);
            System.out.println(beer);
        }


    }
}
