package lesson5.car;

public class Car {

    private String manufacturer;
    private String model;
    private String color;
    private int maxSpeed;
    private int currentSpeed;

    public Car(String manufacturer, String model, String color, int maxSpeed) {
        this.manufacturer = manufacturer;
        this.model = model;
        this.color = color;
        this.maxSpeed = maxSpeed;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public int getCurrentSpeed() {
        return currentSpeed;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public void setCurrentSpeed(int currentSpeed) {
        if (currentSpeed >= 0 && currentSpeed <= maxSpeed) {
            this.currentSpeed = currentSpeed;
        }
    }

    public void accelerate() {
        if (currentSpeed < maxSpeed) {
            currentSpeed++;
        } else {
            System.out.println("Car reached max speed!");
        }
    }

    public void slowDown() {
        if (currentSpeed > 0) {
            currentSpeed--;
        } else {
            System.out.println("Car has stopped");
        }
    }

    public boolean isDriving() {
        if (currentSpeed > 0) {
            return true;
        }

        return false;
    }

    public boolean canAccelerate() {
        if (currentSpeed < maxSpeed) {
            return true;
        }

        return false;
    }

    public boolean isStopped() {
        if (currentSpeed == 0) {
            return true;
        }

        return false;
    }

    public String toString() {
        return "Manufacturer: " + manufacturer + "\n"
                + "Model: " + model + "\n"
                + "Color: " + color + "\n"
                + "Max Speed: " + maxSpeed + "\n"
                + "Current Speed: " + currentSpeed;
    }
}
