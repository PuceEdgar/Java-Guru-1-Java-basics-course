package lesson5.car;

public class CarMain {

    public static void main(String[] args) {

        Car car = new Car("Audi", "S4", "Red", 350);


        while (car.canAccelerate()) {
            car.accelerate();
            if (car.getCurrentSpeed() == car.getMaxSpeed()) {
                System.out.println("Driving at max speed: " + car.getCurrentSpeed() + " km/h");
            }
        }



        while (car.isDriving()) {
            car.slowDown();
            if (car.getCurrentSpeed() == 0) {
                System.out.println("Car has stopped: " + car.getCurrentSpeed() + " km/h");
            }
        }

        System.out.println(car);

    }
}
