package lesson5.employee;

public class EmployeeMain {

    public static void main(String[] args) {


        Company company = new Company("Samsung", "12345");
        Department department = new Department("IT", company);
        Employee programmer = new Employee("111", 3500, department);

        System.out.println(programmer);
        
        programmer.setSalary(5777);
        company.setName("LG");
        department.setName("QA");

        System.out.println(programmer);
    }
}
