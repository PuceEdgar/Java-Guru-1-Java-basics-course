package lesson5.employee;

public class Employee {

    private String contractNumber;
    private double salary;
    private Department department;

    public Employee(String contractNumber, double salary, Department department) {
        this.contractNumber = contractNumber;
        this.salary = salary;
        this.department = department;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public double getSalary() {
        return salary;
    }

    public Department getDepartment() {
        return department;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public String toString() {
        return "Contract Number: " + contractNumber + "\n"
                + "Salary: " + salary + "\n"
                + department;
    }
}
