package lesson5.employee;

public class Company {

    private String name;
    private String registrationNumber;

    public Company(String name, String registrationNumber) {
        this.name = name;
        this.registrationNumber = registrationNumber;
    }

    public String getName() {
        return name;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String toString() {
        return "Company name: " + name + "\n"
                + "Registration number: " + registrationNumber + "\n";
    }
}
