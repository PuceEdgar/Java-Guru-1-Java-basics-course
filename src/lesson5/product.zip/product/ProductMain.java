package lesson5.product;

public class ProductMain {

    public static void main(String[] args) {

        Product beer = new Product("beer", 2.65);

        beer.setDiscount(10);

        double discount = beer.getDiscount();

        for (int i = 0; i < 10; i++) {
            discount = discount+5;
            beer.getActualPrice(discount);
            System.out.println(beer);
        }


    }
}
